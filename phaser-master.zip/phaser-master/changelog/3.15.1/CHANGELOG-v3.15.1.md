# Phaser 3 Change Log

## Version 3.15.1 - Batou - 16th October 2018

* Re-enabled Input Manager resizing, which had been left disabled by mistake.
