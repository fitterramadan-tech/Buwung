# Version 3.88.2 - Minami - 13th February 2025

## Bug Fixes

* Reverted an incorrect change made to the Scale Manager that prevented the `autoCenter: Phaser.Scale.CENTER_BOTH` from working.
